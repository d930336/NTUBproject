//
//  Coupon.swift
//  mainproject
//
//  Created by Benson Yang on 2019/3/14.
//  Copyright © 2019 Benson Yang. All rights reserved.
//

import Foundation
import UIKit

class Coupon {
    
    var Store : String
    var Discount : String
    
    init(Store: String, Discount: String){
        self.Store = Store
        self.Discount = Discount
    }
}
