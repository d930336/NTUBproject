//
//  CenterCell.swift
//  mainproject
//
//  Created by Benson Yang on 2019/3/22.
//  Copyright © 2019 Benson Yang. All rights reserved.
//

import UIKit

class CenterCell: UICollectionViewCell {
    
    @IBOutlet weak var DailyCount: UILabel!
    @IBOutlet weak var TodaySub: UILabel!
    
    
    
    
    
}
