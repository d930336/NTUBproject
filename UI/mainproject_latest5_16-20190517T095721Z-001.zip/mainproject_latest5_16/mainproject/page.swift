//
//  page.swift
//  
//
//  Created by Benson Yang on 2019/3/14.
//

import UIKit

class page: UIpageViewController {

}
